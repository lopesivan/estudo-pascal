
fpcmkcfg -d "basepath=/usr/lib/x86_64-linux-gnu/fpc/3.2.2" -o fpc.cfg
